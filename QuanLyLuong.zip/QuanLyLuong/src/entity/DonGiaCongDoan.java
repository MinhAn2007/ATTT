package entity;

public class DonGiaCongDoan {
	private String id;
	private String kieuDang;
	private String chatLieu;
	private String tenCongDoan;
	private double donGia;
	private int soLuong;

	public DonGiaCongDoan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DonGiaCongDoan(String kieuDang, String chatLieu, String tenCongDoan, double donGia) {
		super();
		this.kieuDang = kieuDang;
		this.chatLieu = chatLieu;
		this.tenCongDoan = tenCongDoan;
		this.donGia = donGia;
	}

	public DonGiaCongDoan(String maCongDoan) {
		super();
		this.tenCongDoan = maCongDoan;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKieuDang() {
		return kieuDang;
	}

	public void setKieuDang(String kieuDang) {
		this.kieuDang = kieuDang;
	}

	public String getChatLieu() {
		return chatLieu;
	}

	public void setChatLieu(String chatLieu) {
		this.chatLieu = chatLieu;
	}

	public String getMaCongDoan() {
		return tenCongDoan;
	}

	public void setMaCongDoan(String maCongDoan) {
		this.tenCongDoan = maCongDoan;
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}

	public String getTenCongDoan() {
		return tenCongDoan;
	}

	public void setTenCongDoan(String tenCongDoan) {
		this.tenCongDoan = tenCongDoan;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

}
